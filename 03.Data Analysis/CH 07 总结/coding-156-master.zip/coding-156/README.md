# python-data-science

本课程会教大家如何使用Python分析和可视化数据，开启Data Science职业之旅。

本课程是Python for Data Science的入门课程，是学习Text Mining，Machine Learning，Deep Learning的基础。

主要包含以下內容：

- anaconda和Jupyter的介绍和安装
- numpy入门
- pandas入门
- 使用numpy+pandas进行数据分析和处理
- 数据可视化：matplotlib入门
- 项目实战